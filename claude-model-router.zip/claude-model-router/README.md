# model-router for Claude Code

A Claude Code mod that picks **Haiku, Sonnet or Opus** and an **effort level** (low, medium, high, xhigh, max) for each prompt, and can switch to them for you.

- **Auto mode**: each prompt is analysed and runs on the recommended model and effort, no questions asked.
- **Recommend mode**: when the recommendation differs from what you're running, a dialog shows it with a short reason. Accept it with one click or pick another.
- **Manual mode**: no analysis and no recommendation. You choose the model and effort yourself.
- **Next prompt only**: `/route next opus high` uses Opus at high effort for your next prompt, then goes back to your mode. Works in any mode.
- **Escalation**: if a response fails (an API error, tests still failing, or you say it's wrong), the next prompt gets more effort or a stronger model. Auto applies it; the other modes suggest it.
- **Sticky by design**: model and effort change only when the difference is clear, so you don't keep losing the prompt cache.
- **Transparent**: the status line shows the mode, the model and effort in use, and (in auto and recommend) the recommendation and why.

Works the same on **Windows and macOS**, in the **terminal** and in the **Desktop app's Code tab**. It's a pure mod: no bash or PowerShell scripts, no Node install, nothing to compile.

---

## How it works

| Step | What happens |
|---|---|
| 0. Classifier | A small model (Haiku, low effort) reads the new message with the previous task and the last answer, and returns its complexity, its sentiment and whether it is feedback on the last result. Feedback inherits the level of the task it refers to; negative feedback raises it. If the classifier fails or times out, the rules decide alone. |
| 1. Prompt submitted | A `prompt.submit` hook scores the prompt from 0 to 100: length, task type (architecture, build, debugging, code, writing, quick Q&A), complexity keywords, code blocks, stack traces, file names and numbered requirements. |
| 2. Context | The score is blended with recent prompts in the session. A short follow-up such as *"now do the same for billing"* is mostly judged by the conversation it continues, however long ago that was. |
| 3. Model | `< haikuMax` → Haiku, `≥ opusMin` → Opus, anything else → Sonnet. |
| 4. Effort | Each model has effort bands over the same score (see [Effort levels](#effort-levels)), so model and effort are one decision. |
| 4a. Limits | Structure (bullets, file names, code blocks) adds at most `scoring.structureCap` points, and build, code and writing requests stop at their `taskCeilings`. A long spec for a simple app therefore lands on Opus medium, not xhigh. |
| 5. Quality first | When the analysis is unsure (the score sits just under a boundary, or the prompt gives nothing to go on), effort goes up one level. Low effort is only used for clearly simple prompts. |
| 6. Stickiness | Model and effort change only when the score clears a boundary by a margin, and not again until a few prompts after a routed switch. The first prompt of a brand-new conversation has no cache to protect, so it is routed without stickiness. |
| 7. Mode | Auto applies the result. Recommend asks only when it would change something. Manual skips steps 1–6 entirely. |
| 8. Switch | A `turn.step` hook sends each main-loop request of the turn with the chosen model and effort. Subagents keep their own. |

Analysis is local and deterministic (well under a millisecond), so there's no noticeable delay and no extra API call.

**Good to know**

- The router never changes your `/model` or effort settings. It overrides them per request, so `/model` and the Desktop model picker keep showing the **session (base) model**, and the status line shows what is actually used, for example `Router auto · Sonnet · high (base claude-opus-5-5)`.
- Changing the model *or the effort* makes Claude Code rewrite the prompt cache. That's why both are sticky. If you're on the first-party API and want effort changes to keep the cache, set `CLAUDE_CODE_MODEL_CAPABILITIES=per_turn_effort` in your environment (a Claude Code setting, not part of this mod).
- A model that doesn't support an effort level gets the nearest level it does support, or none at all. Claude Code handles that.

---

## Requirements

- Claude Code **2.1.325 or newer** (the version whose mod API this was built and tested against), in a terminal or the Claude Desktop app (Code tab).
- Access to the models you route to. If you're on Bedrock, Vertex or a gateway, set `models` in the config to the IDs your provider uses (see [Configuration](#configuration)).

---

## Install

The easiest way is to give Claude Code the zip and let it install the mod for you. It works the same on Windows and macOS, in a terminal or in the Desktop app's Code tab.

### Recommended: let Claude Code install it

1. **Download** `claude-model-router.zip` from this repository (the file in the repo, or the latest release).
2. **Open Claude Code** in any folder: a terminal session, or a session in the Desktop app's Code tab.
3. **Give Claude the zip.** Drag it into the prompt box if your Claude Code accepts file attachments. Otherwise, put the zip's full path in the prompt below.
4. **Paste this prompt** (replace the path if you didn't attach the zip):

```text
Install the Claude Code mod in claude-model-router.zip (attached, or at: <full path to the zip>).

1. Unzip it into a folder that will stay where it is:
   - macOS / Linux: ~/claude-mods/claude-model-router
   - Windows: %USERPROFILE%\claude-mods\claude-model-router
   If that folder already exists, show me what's in it and ask before replacing it.
2. Before installing, read .claude-plugin/plugin.json and hooks/register.ts and tell me in a
   few lines what the mod does, which files it reads and writes, and what it sends anywhere.
3. Install it for my user from that folder:
   claude plugin install model-router --marketplace <that folder>
   If the claude command isn't on my PATH, use the Claude Code executable that is running
   this session.
4. Run "claude plugin list" and confirm model-router is enabled, with its version.
5. Tell me to start a new session to load it.
```

5. **Start a new session.** The status line under the prompt shows `Router recommend · …`.
6. **Check and choose a mode** in the new session:

```text
/route status
```

```text
/route recommend
```

Use `/route auto` instead if you want switches without being asked, or `/route manual` for no analysis. To keep a log of each decision and its token use, also run `/route log on`.

Claude Code reads the mod from the folder in step 1, so **don't move or delete that folder**.

### Update to a new version

Download the new zip, open Claude Code, attach the zip (or use its path), and paste:

```text
Update my model-router Claude Code mod from the new claude-model-router.zip (attached, or at:
<full path to the zip>).

1. Run "claude plugin list" and find the folder model-router is read from ("Read from").
2. Replace that folder's contents with the zip's claude-model-router folder. Show me the old
   and new version from .claude-plugin/plugin.json first, and ask before replacing.
3. Don't touch my settings and logs in ~/.claude/model-router (Windows:
   %USERPROFILE%\.claude\model-router).
4. Run "claude plugin update model-router" and tell me the version it now reports.
5. Tell me to start a new session.
```

Read the CHANGELOG for what changed. Your config file keeps working across versions; new settings use their defaults until you add them.

### Uninstall

```text
Uninstall the model-router Claude Code mod.

1. Run "claude plugin uninstall model-router" and "claude plugin marketplace remove model-router".
2. Show me the folder it was installed from and ask before deleting it.
3. Ask me separately before deleting ~/.claude/model-router (Windows:
   %USERPROFILE%\.claude\model-router), which holds my config and logs.
```

The router never changed your `/model` or effort settings, so nothing else needs restoring.

### If something doesn't work

```text
My model-router Claude Code mod isn't working. Run "claude plugin list" and show me the
model-router entry, run "claude plugin validate" on the folder it's read from, and show me
the last 20 lines of ~/.claude/model-router/routing.log if it exists. Then tell me what's wrong.
```

See also [Troubleshooting](#troubleshooting).

### Install by hand (no prompts)

1. Unzip `claude-model-router.zip` somewhere permanent:
   - macOS: `~/claude-mods/claude-model-router`
   - Windows: `C:\Users\<you>\claude-mods\claude-model-router`
2. Install from that folder:

   macOS:
   ```bash
   claude plugin install model-router --marketplace ~/claude-mods/claude-model-router
   ```
   Windows (PowerShell or cmd):
   ```
   claude plugin install model-router --marketplace C:\Users\<you>\claude-mods\claude-model-router
   ```
3. Start a new Claude Code session, or run `/reload-plugins` in an open one.

### Install straight from GitHub

This only works if the repository holds the **unzipped** mod: `.claude-plugin/` must be at the top of the repository. It won't work if the repository only holds the zip.

```bash
claude plugin install model-router --marketplace YOUR-GITHUB-USER/claude-model-router
```

**In the Desktop app:** click **+** next to the prompt box, then **Plugins** → **Add marketplace**. Enter `YOUR-GITHUB-USER/claude-model-router`, then click **Add plugin**.

### Upgrading from 1.x

- 1.x's **manual** mode (ask before a switch) is now called **recommend**. A saved `manual` mode and a 1.x config file's `"defaultMode": "manual"` are both read as `recommend`, so nothing you see changes. **manual** now means no analysis at all.
- Your existing `config.jsonc` keeps working. The new effort and escalation settings use their defaults until you add them. To get the new commented template, rename or delete the file and start a session. `/route status` tells you when the file is in the 1.x format.
- The dialog and status line now show model **and effort**, e.g. `Sonnet · high`.

---

## The three modes

| | Auto | Recommend | Manual |
|---|---|---|---|
| Analyses each prompt | yes | yes | no |
| Shows a recommendation | in the status line | in the status line and a dialog | no |
| Changes model / effort | automatically | after your click | only when you say so |
| `/route next` | yes | yes | yes |
| On a failed response | applies the higher setting to your next prompt | recommends it in the next dialog | suggests it in a notification |

Your last mode is **remembered across sessions**. Until you choose one, `defaultMode` from the config is used (out of the box: `recommend`).

### Auto

```
/route auto
```

Type your prompts as usual. The status line updates on each prompt:

```
Router auto · Sonnet · high (base claude-opus-5-5) · rec Sonnet · high · code, medium complexity, medium output (score 56)
```

`· held` means the router recommended something else but kept the current setting because of stickiness.

### Recommend

```
/route recommend
```

When the recommendation differs from what you're running, a dialog appears before the prompt runs:

> You're on Opus · high. Recommended: Haiku · low — quick-qa, low complexity, small output (score 0). Which model and effort should run this prompt?
> 1. Haiku · low (recommended)
> 2. Keep Opus · high (current)
> 3. Haiku · medium
> 4. Sonnet · low

- **Accept:** press **Enter** or **1**.
- **Choose another:** pick an option, or type under **Other**, e.g. `opus xhigh`, `sonnet`, or just `high`. A missing part is filled in sensibly.
- **Esc** keeps what you're running, and the prompt still runs.

If nothing would change, there's no dialog. Set `"manualAskOnlyOnChange": false` to be asked every time. In non-interactive runs (`claude -p`, SDK) nobody can answer, so nothing changes.

### Manual

```
/route manual
```

No analysis, no recommendation, no dialog. You choose:
- **Model:** Claude Code's own `/model` (the router stops overriding it).
- **Effort:** the session's own, or `/route effort lock <level>`.
- **One prompt:** `/route next <model> [effort]`.

### Off and lock (unchanged from 1.x)

- `/route off`: the router does nothing except `/route next`. The session's own model and effort are used.
- `/route lock <haiku|sonnet|opus>`: always that model. The router still picks the **effort** per prompt within that model's range (for example Opus at medium for a quick question, high or xhigh for hard work), unless you also run `/route effort lock`.

---

## Next prompt only

```
/route next opus high     # Opus at high effort
/route next sonnet        # Sonnet; effort as usual
/route next max           # current model at max effort
/route next clear         # cancel
```

The override applies to every request of your next prompt's turn, including tool steps, and then your mode takes over again. It works in every mode, including off, and skips the recommend dialog. The status line shows `next: Opus · high` until it's used.

---

## Effort levels

```
/route effort auto            # the router picks the effort (default)
/route effort lock high       # always low, medium, high, xhigh or max
```

Both are remembered across sessions. An effort lock applies in auto, recommend, manual and lock modes; off mode ignores it.

**Default ladder** (auto mode; scores 0–100):

| Score | Model · effort |
|---|---|
| 0–14 | Haiku · low (only when clearly simple; otherwise medium) |
| 15–29 | Haiku · medium |
| 30–47 | Sonnet · medium |
| 48–64 | Sonnet · high |
| 65–74 | Opus · medium |
| 75–89 | Opus · high |
| 90–100 | Opus · xhigh |

The ladder never uses Opus at low effort: a task that would get it runs on Sonnet at high effort instead. Bands for the other scores (for example Haiku · high, Sonnet · xhigh) are used when a model is locked or escalated. Everything here is in the config file.

**Quality first:** when a score is within `uncertaintyMargin` (4) of a model or effort boundary, or the prompt gives no signals at all, the effort goes up one level, up to `maxLevel` for that model.

---

## Escalation after a failure

A response counts as failed when:
- the turn ended in an **API error** or a **refusal**;
- a **test or build run** (`npm test`, `pytest`, `cargo build`, `tsc`, `make` …; configurable) was **still failing** at the end of the turn. A failure that Claude fixed later in the same turn doesn't count;
- your next prompt is a **short complaint** (*"that's wrong"*, *"still failing"*, *"try again"* …; configurable).

The next step up is more effort on the same model (up to `raiseEffortUpTo`), then the next model at high effort or more:

`Haiku · low → Haiku · medium → Sonnet · high → Opus · high → Opus · xhigh → Opus · max`

| Mode | What happens |
|---|---|
| Auto, lock | Your next prompt runs one step up, past stickiness. The status line shows `escalating to … (reason)`. Lock mode only raises the effort. |
| Recommend | The next dialog recommends the higher setting, with the reason. You decide. |
| Manual | A notification suggests it with a ready command, e.g. `/route next opus xhigh`. Nothing changes unless you run it. |
| Off | Ignored. |

The mod never re-sends a prompt by itself. The higher setting applies to the prompt you send next.

---

## All commands

| Command | What it does |
|---|---|
| `/route` or `/route status` | Shows mode, effort mode, base and active model and effort, pending next-prompt override, last decision, escalation, config and log paths, and warnings |
| `/route auto` · `/route recommend` · `/route manual` · `/route off` | Switch mode (remembered) |
| `/route lock <haiku\|sonnet\|opus>` | Always use that model (`/route lock` alone uses `defaultLockModel`) |
| `/route next <model> [effort]` · `/route next <effort>` · `/route next clear` | Next prompt only |
| `/route effort auto` · `/route effort lock <level>` | Effort picked per prompt, or pinned (remembered; `lock` alone uses `defaultLockLevel`) |
| `/route log on` · `/route log off` | Decision log on or off (remembered) |
| `/route reload` | Re-read the config now, and resume routing if it was paused after a model error |
| `/route help` | List the commands |

---

## Configuration

The config file is created with defaults on the first run:

| OS | Path |
|---|---|
| macOS | `~/.claude/model-router/config.jsonc` |
| Windows | `%USERPROFILE%\.claude\model-router\config.jsonc` |

If you set `CLAUDE_CONFIG_DIR`, it's `$CLAUDE_CONFIG_DIR/model-router/config.jsonc` instead.

It's JSON with comments (`//`, `/* */` and trailing commas are fine), and every field is documented inline. Edits take effect on the next prompt. Use `/route reload` to apply them immediately and see any warnings. An invalid value is ignored with a warning and its default kept, so a typo never breaks routing. Delete the file to restore every default.

**Editing on Windows:** Notepad and VS Code both work. Save as UTF-8 (with or without BOM); Windows line endings are fine. Inside JSON strings, write paths with `\\` or `/`.

| Key | Default | Meaning |
|---|---|---|
| `configVersion` | `2` | File format; leave it |
| `defaultMode` | `"recommend"` | `auto`, `recommend`, `manual`, `off` or `lock`, used until you choose with `/route` |
| `defaultLockModel` | `"sonnet"` | Model for `/route lock` with no argument |
| `models.haiku` / `.sonnet` / `.opus` | aliases | What's sent to the API: an alias or a full model ID, e.g. a Bedrock or Vertex ID |
| `thresholds.haikuMax` / `opusMin` | `30` / `65` | Model boundaries on the 0–100 score |
| `thresholds.switchMargin` | `8` | How far past a model boundary a score must go to switch |
| `thresholds.minPromptsBetweenSwitches` | `2` | Cool-down after a routed model or effort change (skipped for two-step jumps; none before the first switch) |
| `context.*` | see file | How earlier conversation and follow-ups count |
| `classifier.enabled` | `true` | Turn the classifier on or off. Off means the rules alone decide, as in 2.2 |
| `classifier.model` / `classifier.effort` | `haiku` / `low` | The model and effort that read each message |
| `classifier.timeoutMs` | `3000` | Give up after this long and fall back to the rules (500–10000) |
| `classifier.negativeBump` | `10` | Points added to the task's level by each negative feedback message |
| `classifier.bands.<complexity>` | simple 0–29, moderate 30–64, complex 48–74, architecture 65–74 | The score range each complexity maps to. The rules' score is held inside it: architecture lands on Opus · medium, and higher levels come from escalation, `/route next` or an effort lock. Raise `max` to allow more (75–89 is Opus high, 90+ xhigh) |
| `scoring.structureCap` | `20` | Bullets, file names, code blocks and stack traces together add at most this; a long spec is more text, not a harder task |
| `scoring.taskCeilings.<type>` | `build`, `code`, `writing`: `70` | Highest score a task type can reach. 70 is the top of the Opus medium band, so these never get xhigh on their own. Architecture and debugging are uncapped. Setting this object replaces the defaults, so list every type you want capped |
| `taskTypes`, `complexityBoosters`, `simplifiers`, `largeOutputKeywords` | see file | Keywords that set the task type and move the score |
| `manualAskOnlyOnChange` | `true` | Recommend mode: ask only when something would change |
| `effort.defaultMode` | `"auto"` | `auto` or `lock`, used until you choose with `/route effort` |
| `effort.defaultLockLevel` | `"high"` | Level for `/route effort lock` with no argument |
| `effort.bands.<model>` | see ladder above | `[{ "from": score, "level": effort }, …]` in rising order |
| `effort.maxLevel.<model>` | haiku `high`, sonnet `xhigh`, opus `max` | Highest level the router picks for each model |
| `effort.uncertaintyMargin` | `4` | How close below a boundary counts as unsure (→ one level more) |
| `effort.lowMaxScore` | `12` | Low effort only when the prompt's own score is at most this |
| `effort.switchMargin` | `5` | How far past an effort boundary a score must go to change effort |
| `escalation.enabled` | `true` | Turn escalation on or off |
| `escalation.raiseEffortUpTo.<model>` | haiku `medium`, sonnet `high`, opus `max` | Raise effort up to this, then move up a model |
| `escalation.feedbackKeywords` / `feedbackMaxWords` | see file / `40` | What counts as "that didn't work" |
| `escalation.testCommandPatterns` / `failurePatterns` | see file | What counts as a test or build run, and as a failure |
| `logging.enabled` / `maxBytes` / `includePromptExcerpt` | `false` / `1000000` / `false` | Decision log |

**Tuning tips**

- **Too many switches:** raise `switchMargin`, `effort.switchMargin` or `minPromptsBetweenSwitches`.
- **More quality:** raise `effort.uncertaintyMargin`, lower the `from` of the higher effort bands, or lower `opusMin`.
- **Lower cost:** raise `haikuMax` and `opusMin`, or lower `effort.maxLevel`.

### Decision log

With logging on, each event is one JSON line in `routing.log`, next to the config:

```json
{"ts":"2026-11-14T10:02:11.000Z","event":"route","mode":"auto","effortMode":"auto","score":0,"ownScore":0,"type":"quick-qa","complexity":"low","output":"small","followUp":false,"from":{"tier":"opus","effort":"high"},"recommended":{"tier":"haiku","effort":"low"},"chosen":{"tier":"haiku","effort":"low"},"decision":"auto-switch","model":"haiku","effort":"low","ms":0}
```

**Events:**
- `route` (one per prompt)
- `next`
- `failure`
- `mode`
- `effort-mode`
- `error`

**`decision` values:** `auto-switch`, `escalated`, `held`, `kept`, `accepted`, `picked`, `declined`, `dismissed` or `next-override`.

Prompt text is **not** logged unless `includePromptExcerpt` is `true`. Lines end in `\n` on every OS.

---

## Token use and the log

Each turn is logged with its model, effort, duration and the token usage the engine reports (`event: "turn"`). Each line also carries the session ID, so entries from different sessions can be told apart. To compare two settings, group the `turn` lines by `effort` and read `usage` for each.

## Privacy and the classifier

With the classifier on, each new message is sent to the classifier model together with an excerpt of the previous task (400 characters) and the last answer (600 characters). This uses your normal Claude Code model access. It's skipped in manual and off modes, for `/route next` prompts, and when `classifier.enabled` is `false`.

## Error handling

- **Never blocks a prompt.** If analysis, config reading or logging fails, the prompt goes through on the current model and effort, and the error goes to the debug log (`claude --debug`). The hooks also have `.catch` handlers that let prompts and tool calls through if a hook fails or overruns.
- **Never re-runs a command.** The test-run watcher only reads results.
- **Bad config:** the last good settings are kept (defaults on the first load), and `/route status` shows the error.
- **Routed model or effort refused** (unknown ID, no access on your provider): the turn is retried on the session's own model and effort, a notification explains what happened, and routing pauses for the session (`Router paused` in the status line). Fix the config, then run `/route reload`.

---

## Uninstall

The easiest way is the [uninstall prompt](#uninstall) in Install. To do it by hand:

1. Remove the plugin (same command on Windows and macOS):
   ```bash
   claude plugin uninstall model-router
   ```
   Desktop app: **+** → **Plugins**, then remove **model-router**.
2. Optionally remove the marketplace entry:
   ```bash
   claude plugin marketplace remove model-router
   ```
3. Optionally delete the config and log folder:
   - macOS: `rm -rf ~/.claude/model-router`
   - Windows (PowerShell): `Remove-Item -Recurse -Force "$env:USERPROFILE\.claude\model-router"`

Your `/model` and effort settings were never changed, so nothing else needs restoring.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| No `Router …` status line | Run `claude plugin list` and check that `model-router` shows **enabled**. Start a new session or run `/reload-plugins`. Run `claude --debug` and look for lines starting with `model-router:`. |
| `/route` is not recognised | Same as above. The command is registered when the session starts. |
| `Router paused (… unavailable)` | Your provider refused that model or effort. Set `models.<tier>` to an ID you can use (or lower `effort.maxLevel`), then run `/route reload`. |
| Effort shows `default` | The session's own effort isn't known until the first request of the session. It appears after that. |
| Too many switches, or never switches | Adjust the margins and thresholds above. Turn the log on to see each score. |
| Feedback routed too low | Check that the classifier is on (`classifier.enabled`) and that `/route status` shows no `classifier gave no answer` in `claude --debug`. Without an answer the rules decide alone. |
| Status line says `held` | The router recommends something else but is protecting the prompt cache (score within the margin, or a switch happened a prompt ago). `/route next <model> <effort>` overrides it for one prompt. |
| A build request ("create a webapp…") is rated too low or high | Tune `taskTypes.build` (weight and keywords) in the config. |
| `/model` shows a different model than the status line | Expected. `/model` shows the session's base model; the router overrides it per request. `/route manual` or `/route off` gives control back to `/model`. |
| No dialog in recommend mode | It only appears when something would change. Set `manualAskOnlyOnChange: false` to be asked every time. There's no dialog in `claude -p` or SDK runs. |
| Escalation fires on unrelated commands | Narrow `escalation.testCommandPatterns`, or set `escalation.enabled` to `false`. |
| Config edits are ignored | Run `/route reload` and check the warnings. |
| Windows: path errors | The router builds paths from `USERPROFILE` (or `CLAUDE_CONFIG_DIR`) with `\` separators. `/route status` prints the paths it uses. |

---

## Development

```
claude-model-router/
├── .claude-plugin/
│   ├── plugin.json          # mod manifest
│   └── marketplace.json     # lets the repo (or folder) be installed directly
├── hooks/
│   ├── hooks.json           # names the hooks module
│   ├── register.ts          # engine wiring: hooks, /route, config, log, status line
│   ├── router-core.ts       # pure logic: config, analysis, model + effort, stickiness, escalation, commands
│   └── config-template.ts   # the commented default config file
├── types/index.d.ts         # $.state contract
├── tests/
│   ├── router-core.test.ts  # unit tests: config, analysis, effort, stickiness, escalation, commands, paths
│   └── modes.test.ts        # engine tests: all modes, next-prompt override, effort lock, escalation, migration
├── tsconfig.json
├── README.md  CHANGELOG.md  LICENSE  .gitignore  .gitattributes
```

```bash
claude plugin validate .
claude plugin test .
```

To try local edits live, run `claude --plugin-dir /path/to/claude-model-router`. The folder is watched, and saving a file reloads the mod.

## License

MIT. See [LICENSE](LICENSE).
